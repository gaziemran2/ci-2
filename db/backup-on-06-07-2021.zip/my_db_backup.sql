#
# TABLE STRUCTURE FOR: tbl_admin
#

DROP TABLE IF EXISTS `tbl_admin`;

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(25) NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `admin_pass` varchar(50) NOT NULL,
  `admin_phone` varchar(11) NOT NULL,
  `admin_photo` varchar(30) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_phone`, `admin_photo`) VALUES (1, 'Emran Gazi', 'gaziemran2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01763061061', 'photo');


#
# TABLE STRUCTURE FOR: tbl_services
#

DROP TABLE IF EXISTS `tbl_services`;

CREATE TABLE `tbl_services` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(20) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_services` (`service_id`, `service_name`) VALUES (1, 'Domain');
INSERT INTO `tbl_services` (`service_id`, `service_name`) VALUES (2, 'Hosting');
INSERT INTO `tbl_services` (`service_id`, `service_name`) VALUES (3, 'Domain & Hosting');
INSERT INTO `tbl_services` (`service_id`, `service_name`) VALUES (7, 'Software');


